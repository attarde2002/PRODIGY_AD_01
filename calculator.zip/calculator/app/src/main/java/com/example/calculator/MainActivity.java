package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private double firstNumber = Double.NaN;
    private double secondNumber;
    private char currentOperation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        setNumericOnClickListener();
        setOperatorOnClickListener();
    }

    private void setNumericOnClickListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                display.append(button.getText().toString());
            }
        };

        findViewById(R.id.button0).setOnClickListener(listener);
        findViewById(R.id.button1).setOnClickListener(listener);
        findViewById(R.id.button2).setOnClickListener(listener);
        findViewById(R.id.button3).setOnClickListener(listener);
        findViewById(R.id.button4).setOnClickListener(listener);
        findViewById(R.id.button5).setOnClickListener(listener);
        findViewById(R.id.button6).setOnClickListener(listener);
        findViewById(R.id.button7).setOnClickListener(listener);
        findViewById(R.id.button8).setOnClickListener(listener);
        findViewById(R.id.button9).setOnClickListener(listener);
    }

    private void setOperatorOnClickListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                if (!Double.isNaN(firstNumber)) {
                    secondNumber = Double.parseDouble(display.getText().toString());
                    display.setText(String.valueOf(calculateResult()));
                    firstNumber = Double.NaN;
                } else {
                    firstNumber = Double.parseDouble(display.getText().toString());
                }
                currentOperation = button.getText().toString().charAt(0);
                display.append(button.getText().toString());
            }
        };

        findViewById(R.id.buttonAdd).setOnClickListener(listener);
        findViewById(R.id.buttonSubtract).setOnClickListener(listener);
        findViewById(R.id.buttonMultiply).setOnClickListener(listener);
        findViewById(R.id.buttonDivide).setOnClickListener(listener);

        findViewById(R.id.buttonEquals).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Double.isNaN(firstNumber)) {
                    secondNumber = Double.parseDouble(display.getText().toString().replace(String.valueOf(currentOperation), ""));
                    display.setText(String.valueOf(calculateResult()));
                    firstNumber = Double.NaN;
                }
            }
        });

        findViewById(R.id.buttonClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText("");
                firstNumber = Double.NaN;
                secondNumber = Double.NaN;
            }
        });
    }

    private double calculateResult() {
        switch (currentOperation) {
            case '+':
                return firstNumber + secondNumber;
            case '-':
                return firstNumber - secondNumber;
            case '*':
                return firstNumber * secondNumber;
            case '/':
                return firstNumber / secondNumber;
            default:
                return 0;
        }
    }
}
